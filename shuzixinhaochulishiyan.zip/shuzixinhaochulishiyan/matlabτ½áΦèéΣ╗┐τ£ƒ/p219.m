Fs=10* 1000;
fp=1500;fs=2500;rs=40;
wp=2*pi*fp/Fs;ws=2*pi*fs/Fs;
Bt=ws-wp ;
alph=0.5842*(rs-21)^0.4+0.07886*(rs-21);
N=ceil((rs-8)/2.285/Bt); 
wc=(wp+ws)/2/pi;
hn=fir1(N,wc,kaiser(N+1,alph));

M=1024;
hk=fft(hn,M);
n=0:N;
subplot(2,2,1);stem(n,hn,'.');
xlabel('n'); ylabel('h(n)');
k=1:M/2;
w=(0:M/2-1)/(M/2);
subplot(2,2,2); plot(w,20*log10(abs(hk(k))));
axis([0,1,-80,5]); xlabel('\omcga/\pi'); ylabel('20lg|Hg(omega)');
grid on

