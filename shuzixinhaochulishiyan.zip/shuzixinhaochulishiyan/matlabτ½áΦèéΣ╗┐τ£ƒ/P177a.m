wp=1;ws=4;Rp=0.1;As=40;
[N,wc]= buttord(wp,ws,Rp,As,'s');
[B,A]= butter(N,wc,'s');
wph=2*pi*4000;
[BH,AH]=lp2hp(B,A,wph);
fk=0:12000/512:12000;wk=2*pi*fk;
Hk= freqs(BH,AH,wk);
plot(fk,20*log10(abs(Hk)));grid on
xlabel('Ƶ��(kHz)');ylabel('����(dB)')
axis([0,6000,-80,5])