wp=2*pi*3000;ws=2*pi*12000;Rp=0.1;As=60;
[N1,wp1]=cheb1ord(wp,ws,Rp,As,'s');
[B1,Al]=cheby1(N1,Rp,wp1,'s');

fk=0:12000/512:12000;wk=2*pi*fk;
Hk= freqs(B1,Al,wk);
plot(fk/1000,20*log10(abs(Hk)));grid on
xlabel('Ƶ��(kHz)');ylabel('����(dB)')
axis([0,12,-70,5])
