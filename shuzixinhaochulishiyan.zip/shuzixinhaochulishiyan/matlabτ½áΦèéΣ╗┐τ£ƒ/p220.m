wlp=0.2*pi;wls=0.35*pi;wus=0.65*pi;wup=0.8*pi;
B=wls-wlp;
N=ceil(12*pi/B);
wp=[(wls+wlp)/2/pi,(wus+wup)/2/pi];
hn=fir1(N,wp,'stop',blackman(N+1));
M=1024;
hk=fft(hn,M);
n=0:N;
subplot(2,2,1);stem(n,hn,'.');
xlabel('n'); ylabel('h(n)');
k=1:M/2;
w=(0:M/2-1)/(M/2);
subplot(2,2,2); plot(w,20*log10(abs(hk(k))));
axis([0,1,-90,5])

