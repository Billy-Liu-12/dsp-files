wp=2*pi*3000;ws=2*pi*12000;Rp=0.1;As=60;
[N,wpo]=ellipord(wp,ws,Rp,As,'s'); 
[B,A]=ellip(N,Rp,As,wpo,'s');
fk=0:12000/512:12000;wk=2*pi*fk;
Hk= freqs(B,A,wk);
plot(fk/1000,20*log10(abs(Hk)));grid on
xlabel('Ƶ��(kHz)');ylabel('����(dB)')
axis([0,12,-80,5])