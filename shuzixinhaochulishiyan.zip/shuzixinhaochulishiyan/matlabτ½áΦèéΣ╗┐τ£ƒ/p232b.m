Fs=10*1000;
f=[1500,2500];
m=[1,0]; rp=1; rs=40;
dat1=(10^(rp/20)-1)/(10^(rp/20)+1);dat2=10^(-rs/20); rip=[dat1,dat2];
[M,fo,mo,w]=remezord(f,m,rip,Fs);
M=M+1; hn=remez(M,fo,mo,w); 
n=0:M;
subplot(2,2,1); stem(n,hn,'.');
axis( [0,M,-0.1,0.4]); xlabel('n');ylabel('h(n)');
FFT_N=512; hw=fft(hn,FFT_N);
w=0:(FFT_N-1);
w=2*w /FFT_N;
subplot(2,2,2); plot(w,20*log10(abs(hw)));
grid on;
axis([0,max(w )/2,-80,10]); xlabel('\omega/pi'); ylabel('����(dB)')

