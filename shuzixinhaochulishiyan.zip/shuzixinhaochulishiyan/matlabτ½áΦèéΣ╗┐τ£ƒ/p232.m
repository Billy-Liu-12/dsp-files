f=[0.2,0.35,0.65,0.8]; 
m=[1,0,1];
rp=1; rs=60;
dat1=(10^(rp/20)-1)/(10^(rp/20)+1); dat2=10^(-rs/20); rip=[dat1,dat2,dat1];
[M,fo,mo,w]=remezord(f,m,rip);
hn=remez(M,fo,mo,w);
hw=fft(hn,512);
n=0:M;
subplot(2,2,1); stem(n,hn,'.');
xlabel('n'); ylabel('h(n)');
grid on
w=0 :511; w=2 * w/512 ;
subplot(2,2,2); plot(w,20*log10(abs(hw)))
grid on
axis([0,max(w)/2,-80,10]);
xlabel('\omega/pi'); ylabel('����(dB)')

