T=1;
wp=0.2*pi/T;ws=0.35*pi/T;rp=1;rs=10;
[N,wc]=buttord(wp,ws,rp,rs,'s');
[B,A]= butter(N,wc,'s') ;
fk=0:14000/512000:14000;wk=2*pi*fk;
Hk= freqs(B,A,wk);
subplot(2,2,1);plot(fk,20*log10(abs(Hk)));grid on
xlabel('Ƶ��(Hz)');ylabel('����(dB)')
axis([0,0.5,-50,5])
[Bz,Az]=impinvar(B,A,1/T); 
k=0:511;fk1=0:14000/512000:14000;wk1=2*pi*fk1;
Hk1= freqs(Bz,Az,wk1);
subplot(2,2,2);plot(wk1/pi,20*log10(abs(Hk1)));grid on
xlabel('w/pi');ylabel('����(dB)')
axis([0,1,-50,5])