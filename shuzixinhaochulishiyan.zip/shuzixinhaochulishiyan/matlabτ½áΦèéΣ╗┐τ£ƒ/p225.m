T=input(' T=');
Bt=pi/16;wp=pi/3;
m=1;
N=ceil((m+1)*2*pi/Bt);
N=N + mod( N + 1,2 );
Np=fix(wp/(2*pi/N));
Ns=N-2*Np-1;
Ak=[ones(1,Np+1),zeros(1,Ns),ones(1,Np)];
Ak(Np+2)= T; Ak(N-Np)=T ;
thetak=-pi*(N-1)*(0:N-1)/N;
Hk=Ak.*exp(j*thetak);
hn=real(ifft(Hk));
Hw = fft(hn,1024);
wk= 2*pi*(0:1023)/1024;
Hgw = Hw.*exp(j*wk*(N-1)/2);
Rp=max(20*log10(abs(Hgw)));
hgmin=min(real(Hgw ));Rs=20*log10(abs(hgmin));
Aw=[1,1,0,0,1,1]; wk1=[0,wp,wp,2*pi-wp,2*pi-wp,2*pi]/pi;
subplot(3,2,1); plot(wk1,Aw ); axis( [0,2,-0.2,1.2] );
xlabel('\omega/pi');ylabel('Hg(k)');
hold on
wk2=(0:N-1)*2/N; plot(wk2,Ak,'.');
n=0 :N-1;
subplot(3,2,3); stem(n,hn,'.');
axis( [0,65,-0.2,0.5] ); xlabel('n'); ylabel('h(n)');
subplot(3,2,5); plot(wk/pi,20*log10(abs(Hgw)));
axis([0,1,-60,3]); grid on; xlabel('\omega/pi');ylabel('20lg| Hg(O)|');

