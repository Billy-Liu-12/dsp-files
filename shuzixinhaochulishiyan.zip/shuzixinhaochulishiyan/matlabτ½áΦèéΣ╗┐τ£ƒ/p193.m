T=1; Fs=1/T;
wpz=0.2;wsz=0.3;
wp=2*tan(wpz*pi/2);ws=2*tan(wsz*pi/2);rp=1;rs=15;
[N,wc]=buttord(wp,ws,rp,rs,'s');
[B,A]=butter(N,wc,'s');
[Bz,Az]= bilinear(B,A,Fs);
fk=0:14000/512:14000;wk=2*pi*fk;
Hk= freqs(Bz,Az,wk);
subplot(2,2,1);plot(fk/1000,20*log10(abs(Hk)));grid on
xlabel('Ƶ��(kHz)');ylabel('����(dB)')
[Nd,wdc]=buttord(wpz,wsz,rp,rs);
[Bdz,Adz]=butter( Nd,wdc);
fk=0:14000/512:14000;wk=2*pi*fk;
Hk= freqs(Bdz,Adz,wk);
subplot(2,2,2);plot(fk,20*log10(abs(Hk)));grid on
xlabel('Ƶ��(kHz)');ylabel('����(dB)')
axis([0,0.5,-50,5])