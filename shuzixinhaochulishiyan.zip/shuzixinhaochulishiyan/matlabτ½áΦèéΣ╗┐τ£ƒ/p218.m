ws= pi/4 ;wp= pi/2 ;
Bt=wp-ws;
N0=ceil(6.2*pi/Bt) ;
N=N0+mod(N0+1,2);
wc=(wp+ws)/2/pi;
hn=fir1(N-1,wc,'high',hanning(N) );
n=0:N-1;
subplot(1,2,1);stem(n,hn,'.');
M=1024;hk=fft(hn,M);k=1:M/2;
w=(0:M/2-1)/(M/2);
subplot(1,2,2);plot(w,20*log10(abs(hk(k))));grid on
xlabel('w/pi');ylabel('����(dB)')
axis([0,1,-80,5])


