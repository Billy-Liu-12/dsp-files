fsl= 2025;fsu=2225;fpl=1500;fpu=2700;Fs=8000;
ws=[2*fsl/Fs,2*fsu/Fs];wp=[2*fpl/Fs,2*fpu/Fs];
rp=1;rs=40;
[N,wpo]=ellipord(wp,ws,rp,rs);
[B,A]=ellip(N,rp,rs,wpo,'stop'); 
