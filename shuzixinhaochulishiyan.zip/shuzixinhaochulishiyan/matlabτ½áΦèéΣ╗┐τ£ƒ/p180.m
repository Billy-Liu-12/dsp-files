wp=2*pi*[2000,9000];ws=2*pi*[4000,7000];Rp=1;As=20;
[Nb,we]=buttord(wp,ws,Rp,As,'s'); 
[BSb,ASb ]=butter(Nb,we,'stop','s');
[Ne,wep]=ellipord(wp,ws,Rp,As,'s'); 
[BSe,ASe]=ellip(Ne,Rp,As,wep,'stop','s'); 