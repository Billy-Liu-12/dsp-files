function st=mstg2
N=800
Fs=10000;T=1/Fs;Tp=N*T;
t=0:T:(N-1)*T;k=0:N-1;f=k/Tp;
Ad=5;Am=5;
fc1=Fs/10;
fm1=fc1/10;
fc2=Fs/20;
fm2=fc2/10;
fc3=Fs/40;
fm3=fc3/10;
xt1=(Ad+Am*cos(2*pi*fm1*t)).*cos(2*pi*fc1*t);
xt2=(Ad+Am*cos(2*pi*fm2*t)).*cos(2*pi*fc2*t);
xt3=(Ad+Am*cos(2*pi*fm3*t)).*cos(2*pi*fc3*t);
st=xt1+xt2+xt3;
fxt=fft(st,N);
figure(7);
subplot(2,1,1)
plot(t,st);grid;xlabel('t/s');ylabel('s(t)');
axis([0,Tp/8,min(st),max(st)]);title('(a) s(t)�Ĳ���')
subplot(2,1,2)
stem(f,abs(fxt)/max(abs(fxt)),'.');grid;title('(b) s(t)��Ƶ�� (N=1600)')
axis([0,Fs/5,0,1.2]);
xlabel('f/Hz');ylabel('����');
N=1800
Fs=10000;T=1/Fs;Tp=N*T;
t=0:T:(N-1)*T;k=0:N-1;f=k/Tp;
fc1=Fs/10;
fm1=fc1/10;
fc2=Fs/20;
fm2=fc2/10;
fc3=Fs/40;
fm3=fc3/10;
xt1=(Ad+Am*cos(2*pi*fm1*t)).*cos(2*pi*fc1*t);
xt2=(Ad+Am*cos(2*pi*fm2*t)).*cos(2*pi*fc2*t);
xt3=(Ad+Am*cos(2*pi*fm3*t)).*cos(2*pi*fc3*t);
st=xt1+xt2+xt3;
fxt=fft(st,N);
figure(11);
subplot(2,1,1)
plot(t,st);grid;xlabel('t/s');ylabel('s(t)');
axis([0,Tp/8,min(st),max(st)]);title('(a) s(t)�Ĳ���')
subplot(2,1,2)
stem(f,abs(fxt)/max(abs(fxt)),'.');grid;title('(b) s(t)��Ƶ�� N=1800')
axis([0,Fs/5,0,1.2]);
xlabel('f/Hz');ylabel('����');
N=2000
Fs=10000;T=1/Fs;Tp=N*T;
t=0:T:(N-1)*T;k=0:N-1;f=k/Tp;
fc1=Fs/10;
fm1=fc1/10;
fc2=Fs/20;
fm2=fc2/10;
fc3=Fs/40;
fm3=fc3/10;
xt1=(Ad+Am*cos(2*pi*fm1*t)).*cos(2*pi*fc1*t);
xt2=(Ad+Am*cos(2*pi*fm2*t)).*cos(2*pi*fc2*t);
xt3=(Ad+Am*cos(2*pi*fm3*t)).*cos(2*pi*fc3*t);
st=xt1+xt2+xt3;
fxt=fft(st,N);
figure(12);
subplot(2,1,1)
plot(t,st);grid;xlabel('t/s');ylabel('s(t)');
axis([0,Tp/8,min(st),max(st)]);title('(a) s(t)�Ĳ���')
subplot(2,1,2)
stem(f,abs(fxt)/max(abs(fxt)),'.');grid;title('(b) s(t)��Ƶ�� N=2000')
axis([0,Fs/5,0,1.2]);
xlabel('f/Hz');ylabel('����');